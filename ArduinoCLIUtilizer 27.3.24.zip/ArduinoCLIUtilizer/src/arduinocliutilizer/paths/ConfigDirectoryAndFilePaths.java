package arduinocliutilizer.paths;

public interface ConfigDirectoryAndFilePaths {
	public static final String configDirectoryFolder = "automatisationConfig";
	public static final String configFileName = configDirectoryFolder + "/arduinoCLIUtilizerConfig.yaml";
}
