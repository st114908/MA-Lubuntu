package arduinocliutilizer.paths;

public interface FQBNStorageFileName {
	public static final String fqbnStorageFileName = "fqbn.txt";
}
