package arduinocliutilizer.configgenerator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.paths.ConfigDirectoryAndFilePaths;
import arduinocliutilizer.paths.DefaultArduinoCLIPath;
import arduinocliutilizer.paths.SelectedFilePathAndContextFinder;

public class ArduinoCLIUtilizerConfigGenerator implements ConfigDirectoryAndFilePaths, DefaultArduinoCLIPath, SelectedFilePathAndContextFinder {
	private String projectPath;
	private String completeConfigDirectoryPath;
	private String completeConfigFilePath;
	private boolean checkedForArduinoCLIFile;
	private boolean arduinoCLIFileFound;
	
	
	public ArduinoCLIUtilizerConfigGenerator() {
		super();
		projectPath = SelectedFilePathAndContextFinder.getProjectOfSelectedFile();
		completeConfigDirectoryPath = projectPath + "/" + configDirectoryFolder;
		completeConfigFilePath = projectPath + "/" + configFileName;
		checkedForArduinoCLIFile = false;
		arduinoCLIFileFound = false;
	}

	
	public boolean checkForArduinoCLIFile() throws IOException{
		checkedForArduinoCLIFile = true;
		ProcessBuilder processBuilder = new ProcessBuilder();
		processBuilder.command("bash", "-c", "export PATH=" + defaultArduinoCLIPath + ":$PATH && arduino-cli config dump");
		Process proc = processBuilder.start();
		try {
			int exitCode = proc.waitFor();
			boolean testSuccessful = (exitCode == 0); 
			arduinoCLIFileFound = testSuccessful;
			return testSuccessful;
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	
	public boolean generateArduinoCLIUtilizerConfigFile() throws IOException{
		File directoryCheck = new File(completeConfigDirectoryPath);
		if (!directoryCheck.exists()){
		    directoryCheck.mkdirs();
		}
		
		File configExistenceCheck = new File(completeConfigFilePath);
		if(configExistenceCheck.exists() && !configExistenceCheck.isDirectory()) {
			return false;
		}
		
		// Use default values and generate the config file with default values.
		Map<String, Object> data = new LinkedHashMap<String, Object>();
	    data.put("arduinoCLIPathSetInPathEnvironment", false);
	    data.put("arduinoCLIDirectory", defaultArduinoCLIPath);
	    // For DumperOptions examples see 
	    // https://www.tabnine.com/code/java/methods/org.yaml.snakeyaml.DumperOptions$LineBreak/getPlatformLineBreak
	    DumperOptions options = new DumperOptions();
	    //options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
	    options.setPrettyFlow(true);
	    options.setLineBreak(DumperOptions.LineBreak.getPlatformLineBreak());
	    Yaml yaml = new Yaml(options);
		FileWriter myWriter = new FileWriter(completeConfigFilePath);
		myWriter.write(yaml.dump(data));
		myWriter.close();
		
		return true;
	}
	
	
	public String generateConfigFileAndHandleMessageTexts() throws IOException{
		boolean configFileCreated = generateArduinoCLIUtilizerConfigFile();
		if(!configFileCreated){
			return "The ArduinoCLIUtilizer config file already exists!";
		}
		
		if(!checkedForArduinoCLIFile){
			checkForArduinoCLIFile();
		}
		
		if(arduinoCLIFileFound){
			return "Successfully generated the ArduinoCLIUtilizer config file!\n"
				+ "You can find it at " + completeConfigFilePath;
		}
		else{
			return "Successfully generated the ArduinoCLIUtilizer config file!\n"
				+ "You can find it at " + completeConfigFilePath + "\n"
					+ "But the ArduinoCLI file (arduino-cli) hasn't been found.\n"
						+ "Either install the ArduinoCLI there or\n"
							+ "adjust the setting arduinoCLIDirectory!";
		}
	}

	
	public boolean isCheckedForArduinoCLIFile() {
		return checkedForArduinoCLIFile;
	}

	
	public boolean isArduinoCLIFileFound() {
		return arduinoCLIFileFound;
	}
}
