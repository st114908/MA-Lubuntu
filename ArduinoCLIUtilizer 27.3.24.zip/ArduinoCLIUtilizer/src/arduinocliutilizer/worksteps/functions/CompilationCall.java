package arduinocliutilizer.worksteps.functions;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.paths.FQBNStorageFileName;
import arduinocliutilizer.paths.SelectedFilePathAndContextFinder;
import arduinocliutilizer.worksteps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.worksteps.common.SaveResponseInfoLocation;
import arduinocliutilizer.worksteps.common.ACLIWorkstep;
import arduinocliutilizer.worksteps.exceptions.NoArduinoCLIConfigFileException;

public class CompilationCall extends ACLIWorkstep implements SelectedFilePathAndContextFinder, SaveResponseInfoLocation, FQBNStorageFileName{

	public static final String messageWindowTitle = "ArduinoCLIUtilizer: Compiling step";
	
	
	public CompilationCall(String foundFqbn, String targetINOFile, boolean saveCompiledFilesNearby, String parentLocation) throws IOException, InterruptedException, NoArduinoCLIConfigFileException {
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler();
		String compilationCommand;
		String compiledFilesDirIfUsed = SelectedFilePathAndContextFinder.getCompiledFilesDirectory();
		if(saveCompiledFilesNearby){
			// arduino-cli compile --fqbn [BOARD] [INOFILE] --output-dir [OUT]
			compilationCommand = "arduino-cli compile --fqbn " + foundFqbn + " " + targetINOFile + " --output-dir " + compiledFilesDirIfUsed + " --format yaml";
		}
		else {
			// arduino-cli compile --fqbn [BOARD] [INOFILE]
			compilationCommand = "arduino-cli compile --fqbn " + foundFqbn + " " + targetINOFile + " --format yaml";
		}
		ReceivedFeedback = commandLineDoer.doShellCommand(compilationCommand);
		
		responseLocation = SaveResponseInfoLocation.saveShellResponseInfo(
			parentLocation, "CompilationInfo.txt",
			compilationCommand, ReceivedFeedback);
		
		if(ReceivedFeedback.exitCode != 0){
			successful = false;
			return;
		}
		Yaml yamlCompileResponse = new Yaml();
		@SuppressWarnings("unchecked")
		Map<String, Object> compileResponse = (Map<String, Object>) yamlCompileResponse.load(ReceivedFeedback.normalFeedback);
		if( !((boolean) compileResponse.get("success")) ){
			successful = false;
			return;
		}
		
		if(saveCompiledFilesNearby){
			// Save fqbn as additional safeguard against Uploads on different board types and for looking it up.
			FileWriter myWriter = new FileWriter(compiledFilesDirIfUsed + "/" + fqbnStorageFileName);
			myWriter.write(foundFqbn);
			myWriter.close();
		}
		
		successful = true;
	}
	
	
	@Override
	public String generateResultMessage(){
		if(successful){
			return "Nothing wrong.";
		}
		else{
			return "Error at the compilation!\n"
					+ "For more details see\n"
					+ responseLocation;
		}
	}
	
}
