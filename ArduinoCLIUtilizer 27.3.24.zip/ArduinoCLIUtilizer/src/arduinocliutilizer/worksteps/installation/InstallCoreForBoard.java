package arduinocliutilizer.worksteps.installation;

import java.io.IOException;

import arduinocliutilizer.worksteps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.worksteps.common.SaveResponseInfoLocation;
import arduinocliutilizer.worksteps.common.ACLIWorkstep;
import arduinocliutilizer.worksteps.exceptions.NoArduinoCLIConfigFileException;

public class InstallCoreForBoard extends ACLIWorkstep implements SaveResponseInfoLocation{
	
	public static final String messageWindowTitle = "ArduinoCLIUtilizer: Core installation";
	
	
	public InstallCoreForBoard(String candidateID, String parentLocation) throws IOException, InterruptedException, NoArduinoCLIConfigFileException{
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler();
		String coreInstallationCommand = "arduino-cli core install " + candidateID + " --format yaml";
		ReceivedFeedback = commandLineDoer.doShellCommand(coreInstallationCommand);
		
		responseLocation = SaveResponseInfoLocation.saveShellResponseInfo(
			parentLocation, "CoreDownloadInfo.txt",
			coreInstallationCommand, ReceivedFeedback);
		
		successful = (ReceivedFeedback.exitCode == 0);
	}
	

	@Override
	public String generateResultMessage(){
		if(successful){
			return "Nothing wrong.";
		}
		else{
			return "Error at the installation of the core for the connected board!\n"
					+ "For more details see\n" + responseLocation;
		}
	}


}
