package arduinocliutilizer.paths;

public interface ConfigDirectoryAndFilePaths {
	public static final String configDirectoryFolder = "automatisationConfig";
	public static final String configFilePath = configDirectoryFolder + "/arduinoCLIUtilizerConfig.yaml";
}
