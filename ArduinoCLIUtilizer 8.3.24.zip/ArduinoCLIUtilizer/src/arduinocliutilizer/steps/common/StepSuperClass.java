package arduinocliutilizer.steps.common;

public class StepSuperClass {
	protected String responseLocation;
	
	public String getResponseLocation(){
		return responseLocation;
	}
}
