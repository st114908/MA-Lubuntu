

#ifndef CUSTOM_TYPES_H_
#define CUSTOM_TYPES_H_
#ifdef __cplusplus
  extern "C" {
#endif
	#include "standardTypes.h"
#ifdef __cplusplus
  }
#endif
#endif
