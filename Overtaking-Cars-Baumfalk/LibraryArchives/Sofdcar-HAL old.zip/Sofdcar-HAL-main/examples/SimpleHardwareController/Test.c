#include <SimpleHardwareController_Connector.h>

#ifdef __cplusplus
extern "C"
{
#endif

    void testFn()
    {
        SimpleHardwareController_DriveController_GetSpeed();
    }

#ifdef __cplusplus
}
#endif