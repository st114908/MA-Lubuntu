#ifndef LINE_FOLLOWING_HPP
#define LINE_FOLLOWING_HPP

#include <Sofdcar-HAL.hpp>

void lineFollowing(DriveController &dc, LineDetector &ld, DistanceSensor &distFront, DistanceSensor &distRear);

#endif