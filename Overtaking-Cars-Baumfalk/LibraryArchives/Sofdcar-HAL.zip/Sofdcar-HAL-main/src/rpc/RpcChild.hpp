#ifndef RPC_CHILD_HPP
#define RPC_CHILD_HPP

class RpcChild
{
};

#endif