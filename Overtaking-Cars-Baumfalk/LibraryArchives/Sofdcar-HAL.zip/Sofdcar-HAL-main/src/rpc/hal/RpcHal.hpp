#ifndef RPC_HAL_HPP
#define RPC_HAL_HPP

#include "../RpcClass.hpp"

extern RpcClass *rpc_createForHal();

#endif