#ifndef SIMPLE_HARDWARE_COINTROLLER_EXAMPLE_TEST_H
#define SIMPLE_HARDWARE_COINTROLLER_EXAMPLE_TEST_H

#ifdef __cplusplus
extern "C"
#endif
    void
    testFn();

#endif