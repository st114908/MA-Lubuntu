package arduinocliutilizer.paths;

public interface DefaultArduinoCLIPath {
	public static final String defaultArduinoCLIPath = "/home/muml/ArduinoCLI";
}
