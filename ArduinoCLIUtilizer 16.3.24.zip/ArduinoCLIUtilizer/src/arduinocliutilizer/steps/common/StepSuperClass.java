package arduinocliutilizer.steps.common;

public class StepSuperClass {
	protected String responseLocation;
	protected ResponseFeedback ReceivedFeedback;
	protected boolean successful;
	
	
	public String getResponseLocation(){
		return responseLocation;
	}
	
	
	public ResponseFeedback getResponseFeedback(){
		return ReceivedFeedback;
	}
	
	
	public boolean isSuccessful() {
		return successful;
	}
}
