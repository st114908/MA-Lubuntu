package arduinocliutilizer.config;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

public class ArduinoCLIUtilizerConfigGenerator {
	private String projectPath;
	
	public String generateConfigFile(){
		String completeConfigDirectoryPath = projectPath + "/" + ConfigFilePath.configDirectoryPath;
		String completeConfigFilePath = projectPath + "/" + ConfigFilePath.configFilePath;
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigDirectoryPath);
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigFilePath);
		
		File directoryCheck = new File(completeConfigDirectoryPath);
		if (!directoryCheck.exists()){
		    directoryCheck.mkdirs();
		}
		
		File config = new File(completeConfigFilePath);
		if(!config.exists() && !config.isDirectory()) {
			// Use default values and generate the config file with default values.
			
			Map<String, Object> data = new LinkedHashMap<String, Object>();
		    data.put("arduinoCLIPathSetInPathEnvironment", false);
		    data.put("arduinoCLIDirectory", "/home/muml/ArduinoCLI");
		    Yaml yaml = new Yaml();
			try {
				FileWriter myWriter = new FileWriter(completeConfigFilePath);
				myWriter.write(yaml.dump(data));
				myWriter.close();
			    
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				return "IOException Occured!";
			}
			
			//System.out.println("ArduinoCLICommandLineHandler: Config generated!");
			return "Successfully generated the ArduinoCLIUtilizer config file!";
		}
		else{
			return "The ArduinoCLIUtilizer config file already exists!";
		}
	}
	

	public ArduinoCLIUtilizerConfigGenerator(String projectPath){
		this.projectPath = projectPath;
	}
}
