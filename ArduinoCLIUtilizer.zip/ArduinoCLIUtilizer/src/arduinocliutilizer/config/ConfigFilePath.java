package arduinocliutilizer.config;

public class ConfigFilePath {
	public static String configDirectoryPath = "automatisationConfig";
	public static String configFilePath = "automatisationConfig/arduinoCLIUtilizerConfig.yaml";
}
