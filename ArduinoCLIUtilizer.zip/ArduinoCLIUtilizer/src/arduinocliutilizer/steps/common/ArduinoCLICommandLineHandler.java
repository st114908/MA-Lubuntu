package arduinocliutilizer.steps.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.config.ArduinoCLIUtilizerConfigGenerator;
import arduinocliutilizer.config.ConfigFilePath;


public class ArduinoCLICommandLineHandler {
	private String projectPath;
	private boolean arduinoCLIPathSetInPathEnvironment;
	private String arduinoCLIDirectory; // /home/muml/ArduinoCLI
	private String potentialArduinoCLIPathCommand;
	private boolean isWindows;
	
	public boolean configFileFound;
	
	public ArduinoCLICommandLineHandler(String projectPath){
		this.projectPath = projectPath;
		String completeConfigDirectoryPath = projectPath + "/" + ConfigFilePath.configDirectoryPath;
		String completeConfigFilePath = projectPath + "/" + ConfigFilePath.configFilePath;
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigDirectoryPath);
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigFilePath);
		
		File fileInputOutput = new File(completeConfigFilePath);
		if(fileInputOutput.exists() && !fileInputOutput.isDirectory()) {
			configFileFound = true;
		}
		else{
			ArduinoCLIUtilizerConfigGenerator generator = new ArduinoCLIUtilizerConfigGenerator(projectPath);
			generator.generateConfigFile();
			//System.out.println("ArduinoCLICommandLineHandler: Config generated!");
			configFileFound = false;
		}
		
		// Read the config file.
		//System.out.println("ArduinoCLICommandLineHandler: Reading config ...");
		
		try {
			InputStream inputStream = new FileInputStream(new File(completeConfigFilePath));
			Yaml yaml = new Yaml();
			Map<String, Object> loadedData = yaml.load(inputStream);
			arduinoCLIPathSetInPathEnvironment = (boolean) loadedData.get("arduinoCLIPathSetInPathEnvironment");
			arduinoCLIDirectory = (String) loadedData.get("arduinoCLIDirectory");
			inputStream.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//System.out.println("ArduinoCLICommandLineHandler: Config read!");
		if(arduinoCLIPathSetInPathEnvironment){
			potentialArduinoCLIPathCommand = "";
		}
		else{
			potentialArduinoCLIPathCommand = String.format("export PATH=%s && ", arduinoCLIDirectory);
		}
		
		isWindows = System.getProperty("os.name").toLowerCase().startsWith("windows");
	}
	
	public ResponseFeedback doShellCommand(String commandSequence) throws IOException, InterruptedException{
		
		//Runtime rt = Runtime.getRuntime();
		//String[] commands = {"bash", "-c", "echo path && echo dummy && arduino-cli -h"};
		//Process proc = rt.exec(commands);

		// Processbuilder is more intuitive to use.
		ProcessBuilder processBuilder = new ProcessBuilder();
		if(isWindows){
			processBuilder.command("cmd.exe", "/c", potentialArduinoCLIPathCommand + commandSequence);
		}
		else{
			processBuilder.command("bash", "-c", potentialArduinoCLIPathCommand + commandSequence);
		}
		Process proc = processBuilder.start();
		
		// https://stackoverflow.com/questions/5711084/java-runtime-getruntime-getting-output-from-executing-a-command-line-program
		BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
		BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
		int exitCode = proc.waitFor();
		
		// Read the output from the command
		String currentNormalFeedback = null;
		String normalFeedback = "";
		while ((currentNormalFeedback = stdInput.readLine()) != null) {
		    //System.out.println(currentNormalFeedback);
			normalFeedback += currentNormalFeedback + "\n";
		}
		// Read any errors from the attempted command
		String currentErrorFeedback = null;
		String errorFeedback = "";
		while ((currentErrorFeedback = stdError.readLine()) != null) {
		    //System.out.println(currentErrorFeedback);
			errorFeedback += currentErrorFeedback + "\n";
		}
		
		return new ResponseFeedback(exitCode, normalFeedback, errorFeedback);
	}
	
}
