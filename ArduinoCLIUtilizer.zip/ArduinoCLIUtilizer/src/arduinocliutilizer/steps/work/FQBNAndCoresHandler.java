package arduinocliutilizer.steps.work;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;

public class FQBNAndCoresHandler extends StepsSuperClass{
	public boolean handleFQBNAndCores(String foundFqbn, String parentLocation) throws IOException, InterruptedException {
		// Check if the FQBN can be found in the list of available boards:
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler(SelectedFilePathFinder.getProjectOfSelectedFile());
		ResponseFeedback feedbackKnownBoards = commandLineDoer.doShellCommand("arduino-cli board listall --format yaml");
		Yaml yamlKnownBoards = new Yaml();
		Map<String, Object> yamlKnownBoardsInterpreted = (Map<String, Object>) yamlKnownBoards.load(feedbackKnownBoards.normalFeedback);
		ArrayList<Map<String, Object>> installedInstalledBoardDataList = (ArrayList<Map<String, Object>>) yamlKnownBoardsInterpreted.get("boards");
		boolean matchFound = false;
		for(Map<String, Object> currentEntry: installedInstalledBoardDataList){
			String currentFqbn = (String) currentEntry.get("fqbn");
			boolean currentIsHidden = (boolean) currentEntry.get("ishidden");
			if( foundFqbn.equals(currentFqbn) && !currentIsHidden ){
				matchFound = true;
				break;
			}
		}
		// If necessary: Download necessary core:
		if(!matchFound){
			String boardPlatformId = foundFqbn.substring(0, foundFqbn.lastIndexOf(":"));
			commandLineDoer.doShellCommand("arduino-cli core update-index");
			String coreInstallationCommand = "arduino-cli core install " + boardPlatformId + " --format yaml";
			ResponseFeedback feedbackCoreInstalation = commandLineDoer.doShellCommand(coreInstallationCommand);
			saveShellResponseInfoAndLocation(
				parentLocation, "CoreDownloadInfo.txt",
				coreInstallationCommand, feedbackCoreInstalation);
			if(feedbackCoreInstalation.exitCode != 0){
				return false;
			}
		}
		return true;
	}
}
