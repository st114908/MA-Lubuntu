package arduinocliutilizer.steps.work;

import java.io.IOException;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;

public class CompilationStep extends StepsSuperClass {
	public boolean performCompilation(String foundFqbn, String foundPortAddress, String target, boolean saveCompiledFilesNearby, String parentLocation) throws IOException, InterruptedException {
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler(SelectedFilePathFinder.getProjectOfSelectedFile());
		String compilationCommand;
		if(saveCompiledFilesNearby){
			// arduino-cli compile --fqbn [BOARD] [INOFILE] --output-dir [OUT]
			String compiledFilesDir = SelectedFilePathFinder.getCompiledFilesDirectory();
			compilationCommand = "arduino-cli compile --port " + foundPortAddress + " --fqbn " + foundFqbn + " " + target + " --output-dir " + compiledFilesDir + " --format yaml";
		}
		else {
			// arduino-cli compile --fqbn [BOARD] [INOFILE]
			compilationCommand = "arduino-cli compile --port " + foundPortAddress + " --fqbn " + foundFqbn + " " + target + " --format yaml";
		}
		ResponseFeedback feedbackCompilation = commandLineDoer.doShellCommand(compilationCommand);
		//System.out.println(feedbackCompilation);
		saveShellResponseInfoAndLocation(
			parentLocation, "CompilationInfo.txt",
			compilationCommand, feedbackCompilation);
		
		if(feedbackCompilation.exitCode != 0){
			return false;
		}
		Yaml yamlCompileResponse = new Yaml();
		Map<String, Object> compileResponse = (Map<String, Object>) yamlCompileResponse.load(feedbackCompilation.normalFeedback);
		if( !((boolean) compileResponse.get("success")) ){
			return false;
		}
		return true;
	}
}
