package arduinocliutilizer.steps.work;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import arduinocliutilizer.steps.common.ResponseFeedback;

public class StepsSuperClass {
	private String responseLocation;
	
	public void saveShellResponseInfoAndLocation(String directory, String name, String command, ResponseFeedback feedback) throws IOException{
		File directoryCheck = new File(directory + "/SavedResponses");
		if (!directoryCheck.exists()){
		    directoryCheck.mkdirs();
		}
		
		String completeFileLocation = directory + "/SavedResponses/" + name;
		BufferedWriter writer = new BufferedWriter(new FileWriter(completeFileLocation, false));
	    writer.write("Command:\n" + command + "\n\n");
	    writer.append("Result:\n");
	    writer.append("Exit code: " + feedback.exitCode + "\n\n\n");
	    writer.append("Normal response stream:\n" + feedback.normalFeedback + "\n\n\n");
	    writer.append("Error response stream:\n" + feedback.errorFeedback + "\n");
	    writer.close();
	    
	    responseLocation = completeFileLocation;
	}
	
	public String getResponseLocation(){
		return responseLocation;
	}
}
