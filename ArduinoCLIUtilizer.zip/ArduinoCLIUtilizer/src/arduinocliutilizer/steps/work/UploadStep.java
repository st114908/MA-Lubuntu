package arduinocliutilizer.steps.work;

import java.io.IOException;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;

public class UploadStep extends StepsSuperClass{
	public boolean performUpload(String foundPortAddress, String foundFqbn, String target, String parentLocation) throws IOException, InterruptedException{
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler(SelectedFilePathFinder.getProjectOfSelectedFile());
		String uploadCommand;
		if(target.endsWith(".ino")){
			// arduino-cli upload --port [PORT] --fqbn [BOARD]  [INOFILE]
			uploadCommand = "arduino-cli upload --port " + foundPortAddress + " --fqbn " + foundFqbn + " " + target + " --format yaml";
		}
		else{
			// arduino-cli upload --port [PORT] --fqbn [BOARD] --input-file [HEXFILE]
			uploadCommand = "arduino-cli upload --port " + foundPortAddress + " --fqbn " + foundFqbn + " --input-file " + target + " --format yaml";
		}
		ResponseFeedback feedbackUpload = commandLineDoer.doShellCommand(uploadCommand);
		saveShellResponseInfoAndLocation(
			parentLocation, "UploadInfo.txt",
			uploadCommand, feedbackUpload);
		
		if(feedbackUpload.exitCode != 0){
			return false;
		}
		return true;
	}
}
