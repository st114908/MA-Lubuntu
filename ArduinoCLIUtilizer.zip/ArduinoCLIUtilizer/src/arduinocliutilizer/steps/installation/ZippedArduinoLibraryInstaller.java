package arduinocliutilizer.steps.installation;

import java.io.IOException;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;

public class ZippedArduinoLibraryInstaller {
	public static ResponseFeedback installZippedArduinoLibrary(String pathToZip) throws IOException, InterruptedException{
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler(SelectedFilePathFinder.getProjectOfSelectedFile());
		commandLineDoer.doShellCommand("arduino-cli config set library.enable_unsafe_install true");
		ResponseFeedback feedback = commandLineDoer.doShellCommand("arduino-cli lib install --zip-path " + pathToZip + " --no-overwrite");
		return feedback;
	}
}
