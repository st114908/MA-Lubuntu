package arduinocliutilizer.popup.actions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;
import arduinocliutilizer.steps.work.CompilationStep;
import arduinocliutilizer.steps.work.ConnectedBoardsFinder;
import arduinocliutilizer.steps.work.FQBNAndCoresHandler;
import arduinocliutilizer.steps.work.UploadStep;

public class CompileAndUploadArduinoProjectAction extends AutoSelectionAndInstallation implements IObjectActionDelegate {

	private Shell shell;
	
	/**
	 * Constructor for Action1.
	 */
	public CompileAndUploadArduinoProjectAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		/*MessageDialog.openInformation(
			shell,
			"ArduinoCLIUtilizer",
			"Verify Arduino project was executed.");*/
		
		String parentLocation = SelectedFilePathFinder.getParentOfSelectedFile();
		try {
			boolean autoSelectionAndInstallationSuccessful = autoSelectionAndInstallation(shell, parentLocation);
			if(!autoSelectionAndInstallationSuccessful){
				return;
			}
			
			String foundFqbn = getFoundFqbn();
			String foundPortAddress = getFoundPortAddress();
			
			String target = SelectedFilePathFinder.getLocationOfSelectedFile();
			
			// Compilation:
			CompilationStep CompilationStepInstance = new CompilationStep();
			boolean compilationOK = CompilationStepInstance.performCompilation(foundFqbn, foundPortAddress, target, false, parentLocation);
			if(!compilationOK){
				MessageDialog.openInformation(
						shell,
						"ArduinoCLIUtilizer: Compiling step",
						"Error at the compilation!\n"+
							"For more details see\n"+
								CompilationStepInstance.getResponseLocation());
					return;
			}
			
			// Upload:
			UploadStep UploadStepInstance = new UploadStep();
			boolean uploadOK = UploadStepInstance.performUpload(foundPortAddress, foundFqbn, target, parentLocation);
			if(!uploadOK){
				MessageDialog.openInformation(
						shell,
						"ArduinoCLIUtilizer: Upload step",
						"Error at the upload!\n"+
							"For more details see\n"+
								UploadStepInstance.getResponseLocation());
				return;
			}
			
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer: After all steps",
					"Code compiled and uploaded successfully!");
		}
		
		catch (IOException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"IOException occured!\n"+
					"Please make sure that none of the infolved files are opened by a program and then try again.");
			e.printStackTrace();
		} catch (InterruptedException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"The process has been interrupted!");
			e.printStackTrace();
		}
		
		/*try {
			commandLineDoer.doShellCommand("arduino-cli config set library.enable_unsafe_install false");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//System.out.println(feedback.toString());
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

}
