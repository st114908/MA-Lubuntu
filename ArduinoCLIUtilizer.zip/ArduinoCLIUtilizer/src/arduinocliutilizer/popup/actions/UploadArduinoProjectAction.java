package arduinocliutilizer.popup.actions;

import java.io.IOException;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import arduinocliutilizer.steps.common.SelectedFilePathFinder;
import arduinocliutilizer.steps.work.CompilationStep;
import arduinocliutilizer.steps.work.UploadStep;

public class UploadArduinoProjectAction extends AutoSelectionAndInstallation implements IObjectActionDelegate {

	private Shell shell;
	
	/**
	 * Constructor for Action1.
	 */
	public UploadArduinoProjectAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		/*MessageDialog.openInformation(
			shell,
			"ArduinoCLIUtilizer",
			"Verify Arduino project was executed.");*/
		
		String parentLocation = SelectedFilePathFinder.getParentOfSelectedFile();
		try {
			boolean autoSelectionAndInstallationSuccessful = autoSelectionAndInstallation(shell, parentLocation);
			if(!autoSelectionAndInstallationSuccessful){
				return;
			}
			
			String foundFqbn = getFoundFqbn();
			String foundPortAddress = getFoundPortAddress();
			
			String target = SelectedFilePathFinder.getLocationOfSelectedFile();
			
			// Upload:
			UploadStep UploadStepInstance = new UploadStep();
			boolean uploadOK = UploadStepInstance.performUpload(foundPortAddress, foundFqbn, target, parentLocation);
			if(!uploadOK){
				MessageDialog.openInformation(
						shell,
						"ArduinoCLIUtilizer: Upload step",
						"Error at the upload!\n"+
							"For more details see\n"+
								UploadStepInstance.getResponseLocation());
				return;
			}
			
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer: Upload step",
					"Code uploaded successfully!");
		}
		
		catch (IOException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"IOException occured!\n"+
					"Please make sure that none of the infolved files are opened by a program and then try again.");
			e.printStackTrace();
		} catch (InterruptedException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"The process has been interrupted!");
			e.printStackTrace();
		}
		
		/*try {
			commandLineDoer.doShellCommand("arduino-cli config set library.enable_unsafe_install false");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//System.out.println(feedback.toString());
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

}
