package arduinocliutilizer.popup.actions;



import java.io.IOException;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IProject;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;
import arduinocliutilizer.steps.installation.ZippedArduinoLibraryInstaller;

public class InstallZippedArduinoLibraryAction implements IObjectActionDelegate {

	private Shell shell;
	
	/**
	 * Constructor for Action1.
	 */
	public InstallZippedArduinoLibraryAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		/*MessageDialog.openInformation(
			shell,
			"ArduinoCLIUtilizer",
			"Install zipped arduino library was executed.");*/
		
		/*
		// From VonC's answer on https://stackoverflow.com/questions/585802/how-to-get-the-selected-node-in-the-package-explorer-from-an-eclipse-plugin
		IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
		ISelection selection = window.getSelectionService().getSelection("org.eclipse.jdt.ui.PackageExplorer");
		
		// See mechatronicuml-cadapter-component-container/org.muml.arduino.adapter.container.ui/src/org/muml/arduino/adapter/container/ui/popupMenus/AcceleoGenerateArduinoContainerCodeAction.java
		IFile selectedFile = (IFile) ((IStructuredSelection) selection).toList().get(0);
		URI modelURI = URI.createPlatformResourceURI(selectedFile.getFullPath().toString(), true);
		IContainer parent = selectedFile.getParent();
		IProject project = selectedFile.getProject();

		/*MessageDialog.openInformation(
				shell,
				"ArduinoCLIUtilizer IFile",
				selectedFile.getLocation().toString());
		
		MessageDialog.openInformation(
				shell,
				"ArduinoCLIUtilizer parent",
				parent.getLocation().toString());
		
		MessageDialog.openInformation(
				shell,
				"ArduinoCLIUtilizer project",
				project.getLocation().toString());*/

		try {
			ResponseFeedback feedback = ZippedArduinoLibraryInstaller.installZippedArduinoLibrary(SelectedFilePathFinder.getLocationOfSelectedFile());
			//System.out.println(feedback.toString());
			if(feedback.exitCode == 0){
				MessageDialog.openInformation(
						shell,
						"ArduinoCLIUtilizer",
						"Library installed");
			}
			else{
				MessageDialog.openInformation(
						shell,
						"ArduinoCLIUtilizer",
						"Installation did not end normal! Response:\n"+
						feedback.normalFeedback+"\n"+feedback.errorFeedback);
			}
		} catch (IOException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"IOException occured!\n"+
					"The stack trace has beeen printed in the console of the starting eclipse window");
			e.printStackTrace();
		} catch (InterruptedException e) {
			MessageDialog.openInformation(
					shell,
					"ArduinoCLIUtilizer",
					"The installation has been interrupted!\n"+
					"The stack trace has beeen printed in the console of the starting eclipse window");
			e.printStackTrace();
		}
		
		/*try {
			commandLineDoer.doShellCommand("arduino-cli config set library.enable_unsafe_install false");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		//System.out.println(feedback.toString());
		
		//.getProject().getFolder("arduino-containers");
		
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

}
