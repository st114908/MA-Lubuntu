#ifdef __cplusplus
extern "C" {
#endif
// Start of user code FORINCLUDES

// End of user code
#include "standardTypes.h"
#include "customTypes.h"
void CI_DRIVECONTROLLERFDRIVECONTROLLERvelocityPortaccessCommand(int16_T* velocity);
// Start of user code API

// End of user code
#ifdef __cplusplus
}
#endif
