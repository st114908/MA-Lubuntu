#ifdef __cplusplus
extern "C" {
#endif
// Start of user code FORINCLUDES

// End of user code
#include "standardTypes.h"
#include "customTypes.h"
void CI_FRONTDISTANCESENSORSDISTANCESENSORdistancePortaccessCommand(int32_T* distance);
// Start of user code API

// End of user code
#ifdef __cplusplus
}
#endif
