package arduinocliutilizer.popup.actions;

import java.io.IOException;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

import arduinocliutilizer.config.ArduinoCLIUtilizerConfigGenerator;

public class GenerateArduinoCLIUtilizerConfigAction implements IObjectActionDelegate {

	private Shell shell;
	
	/**
	 * Constructor for Action1.
	 */
	public GenerateArduinoCLIUtilizerConfigAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {
		
		//IWorkbenchWindow window = PlatformUI.getWorkbench().getActiveWorkbenchWindow();
		//ISelection selection = window.getSelectionService().getSelection("org.eclipse.jdt.ui.PackageExplorer");
		
		// See mechatronicuml-cadapter-component-container/org.muml.arduino.adapter.container.ui/src/org/muml/arduino/adapter/container/ui/popupMenus/AcceleoGenerateArduinoContainerCodeAction.java
		//IFile selectedFile = (IFile) ((IStructuredSelection) selection).toList().get(0);
		//URI modelURI = URI.createPlatformResourceURI(selectedFile.getFullPath().toString(), true);
		//IContainer parent = selectedFile.getParent();
		//IProject project = selectedFile.getProject();
		
		ArduinoCLIUtilizerConfigGenerator Generator = new ArduinoCLIUtilizerConfigGenerator();
		try {
			MessageDialog.openInformation(
				shell,
				"ArduinoCLIUtilizer",
				Generator.generateConfigFile());
		}
		catch (IOException e) {
			MessageDialog.openInformation(
				shell,
				"ArduinoCLIUtilizer",
				"IOException occured!\n"+
					"Please make sure that nothing blocks the generation of\n"+
						"the directory automatisationConfig and the file arduinoCLIUtilizerConfig.yaml"+
							"and then try again.");
			e.printStackTrace();
		}
	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

}
