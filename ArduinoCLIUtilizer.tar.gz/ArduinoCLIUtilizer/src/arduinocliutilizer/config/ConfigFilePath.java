package arduinocliutilizer.config;

public class ConfigFilePath {
	public static String configDirectoryFolder = "automatisationConfig";
	public static String configFilePath = configDirectoryFolder + "/arduinoCLIUtilizerConfig.yaml";
}
