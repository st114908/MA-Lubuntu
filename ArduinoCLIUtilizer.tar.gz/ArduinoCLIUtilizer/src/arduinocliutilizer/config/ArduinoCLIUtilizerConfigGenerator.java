package arduinocliutilizer.config;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.steps.common.SelectedFilePathFinder;

public class ArduinoCLIUtilizerConfigGenerator {
	
	public String generateConfigFile() throws IOException{
		String projectPath = SelectedFilePathFinder.getProjectOfSelectedFile();
		String completeConfigDirectoryPath = projectPath + "/" + ConfigFilePath.configDirectoryFolder;
		String completeConfigFilePath = projectPath + "/" + ConfigFilePath.configFilePath;
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigDirectoryPath);
		//System.out.println("ArduinoCLICommandLineHandler: " + completeConfigFilePath);
		
		File directoryCheck = new File(completeConfigDirectoryPath);
		if (!directoryCheck.exists()){
		    directoryCheck.mkdirs();
		}
		
		File configExistenceCheck = new File(completeConfigFilePath);
		if(!configExistenceCheck.exists() && !configExistenceCheck.isDirectory()) {
			// Use default values and generate the config file with default values.
			
			Map<String, Object> data = new LinkedHashMap<String, Object>();
		    data.put("arduinoCLIPathSetInPathEnvironment", false);
		    data.put("arduinoCLIDirectory", "/home/muml/ArduinoCLI");
		    Yaml yaml = new Yaml();
			try {
				FileWriter myWriter = new FileWriter(completeConfigFilePath);
				myWriter.write(yaml.dump(data));
				myWriter.close();
			    
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// e.printStackTrace();
				return "IOException Occured!";
			}
			
			
			/*return "Successfully generated the ArduinoCLIUtilizer config file!\n"
				+ "But check if the ArduinoCLI file (arduino-cli) exists at /home/muml/ArduinoCLI.\n"
					+ "If not, then either install the ArduinoCLI there or\n"
						+ "adjust the setting arduinoCLIDirectory!";*/
			ProcessBuilder processBuilder = new ProcessBuilder();
			processBuilder.command("bash", "-c", "export PATH=/home/muml/ArduinoCLI:$PATH && arduino-cli config dump");
			Process proc = processBuilder.start();
			int exitCode = 10;
			try {
				exitCode = proc.waitFor();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			System.out.println(exitCode);
			if(exitCode == 0){
				return "Successfully generated the ArduinoCLIUtilizer config file!";
			}
			else{
				return "Successfully generated the ArduinoCLIUtilizer config file!\n"
					+ "But the ArduinoCLI file (arduino-cli) hasn't been found.\n"
						+ "Either install the ArduinoCLI there or\n"
							+ "adjust the setting arduinoCLIDirectory!";
			}
		}
		else{
			return "The ArduinoCLIUtilizer config file already exists!";
		}
	}
}
