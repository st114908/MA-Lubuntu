package arduinocliutilizer.steps.exceptions;

public class FQBNErrorEception extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5971979415141102350L;

	public FQBNErrorEception(String errorMessage){
		super(errorMessage);
	}
}
