package arduinocliutilizer.steps.installation;

import java.io.IOException;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.exceptions.NoArduinoCLIConfigFileException;

public class ZippedArduinoLibraryInstaller {
	public static ResponseFeedback installZippedArduinoLibrary(String pathToZip) throws IOException, InterruptedException, NoArduinoCLIConfigFileException{
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler();
		commandLineDoer.doShellCommand("arduino-cli config set library.enable_unsafe_install true");
		ResponseFeedback feedback = commandLineDoer.doShellCommand("arduino-cli lib install --zip-path " + pathToZip + " --no-overwrite");
		return feedback;
	}
}
