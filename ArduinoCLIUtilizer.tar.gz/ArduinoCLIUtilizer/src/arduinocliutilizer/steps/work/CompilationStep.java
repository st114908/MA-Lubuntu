package arduinocliutilizer.steps.work;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.steps.common.ArduinoCLICommandLineHandler;
import arduinocliutilizer.steps.common.ResponseFeedback;
import arduinocliutilizer.steps.common.SelectedFilePathFinder;
import arduinocliutilizer.steps.exceptions.NoArduinoCLIConfigFileException;

public class CompilationStep extends StepsSuperClass {
	private String fqbnStorageFileName = "fqbn.txt";
	
	public boolean performCompilation(String foundFqbn, String foundPortAddress, String target, boolean saveCompiledFilesNearby, String parentLocation) throws IOException, InterruptedException, NoArduinoCLIConfigFileException {
		ArduinoCLICommandLineHandler commandLineDoer = new ArduinoCLICommandLineHandler();
		String compilationCommand;
		String compiledFilesDirIfUsed = SelectedFilePathFinder.getCompiledFilesDirectory();
		if(saveCompiledFilesNearby){
			// arduino-cli compile --fqbn [BOARD] [INOFILE] --output-dir [OUT]
			compilationCommand = "arduino-cli compile --port " + foundPortAddress + " --fqbn " + foundFqbn + " " + target + " --output-dir " + compiledFilesDirIfUsed + " --format yaml";
		}
		else {
			// arduino-cli compile --fqbn [BOARD] [INOFILE]
			compilationCommand = "arduino-cli compile --port " + foundPortAddress + " --fqbn " + foundFqbn + " " + target + " --format yaml";
		}
		ResponseFeedback feedbackCompilation = commandLineDoer.doShellCommand(compilationCommand);
		//System.out.println(feedbackCompilation);
		saveShellResponseInfoAndLocation(
			parentLocation, "CompilationInfo.txt",
			compilationCommand, feedbackCompilation);
		
		if(feedbackCompilation.exitCode != 0){
			return false;
		}
		Yaml yamlCompileResponse = new Yaml();
		@SuppressWarnings("unchecked")
		Map<String, Object> compileResponse = (Map<String, Object>) yamlCompileResponse.load(feedbackCompilation.normalFeedback);
		if( !((boolean) compileResponse.get("success")) ){
			return false;
		}
		
		// Save fqbn as safeguard against Uploads on different board types.
		if(saveCompiledFilesNearby){
			FileWriter myWriter = new FileWriter(compiledFilesDirIfUsed + "/" + fqbnStorageFileName);
			myWriter.write(foundFqbn);
			myWriter.close();
		}
		return true;
	}
}
