package arduinocliutilizer.steps.common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import arduinocliutilizer.config.ConfigFilePath;
import arduinocliutilizer.steps.exceptions.NoArduinoCLIConfigFileException;


public class ArduinoCLICommandLineHandler {
	private boolean arduinoCLIPathSetInPathEnvironment;
	private String arduinoCLIDirectory; // /home/muml/ArduinoCLI
	private String potentialArduinoCLIPathCommand;
	//private boolean isWindows;
	
	
	public ArduinoCLICommandLineHandler() throws IOException, NoArduinoCLIConfigFileException{
		String projectPath = SelectedFilePathFinder.getProjectOfSelectedFile();
		String completeConfigFilePath = projectPath + "/" + ConfigFilePath.configFilePath;
		
		File fileInputOutput = new File(completeConfigFilePath);
		if(fileInputOutput.exists() && !fileInputOutput.isDirectory()) {
		}
		else{
			throw new NoArduinoCLIConfigFileException("The config file is missing!");
		}
		
		// Read the config file.
		//System.out.println("ArduinoCLICommandLineHandler: Reading config ...");
		
		InputStream inputStream = new FileInputStream(new File(completeConfigFilePath));
		Yaml yaml = new Yaml();
		Map<String, Object> loadedData = yaml.load(inputStream);
		arduinoCLIPathSetInPathEnvironment = (boolean) loadedData.get("arduinoCLIPathSetInPathEnvironment");
		arduinoCLIDirectory = (String) loadedData.get("arduinoCLIDirectory");
		inputStream.close();
		
		//System.out.println("ArduinoCLICommandLineHandler: Config read!");
		if(arduinoCLIPathSetInPathEnvironment){
			potentialArduinoCLIPathCommand = "";
		}
		else{
			potentialArduinoCLIPathCommand = "export PATH=" + arduinoCLIDirectory + ":$PATH && ";
		}
		
		//isWindows = System.getProperty("os.name").toLowerCase().startsWith("windows");
	}
	
	public ResponseFeedback doShellCommand(String commandSequence) throws IOException, InterruptedException{
		
		//Runtime rt = Runtime.getRuntime();
		//String[] commands = {"bash", "-c", "echo path && echo dummy && arduino-cli -h"};
		//Process proc = rt.exec(commands);

		// Processbuilder is more intuitive to use.
		ProcessBuilder processBuilder = new ProcessBuilder();
		//if(isWindows){
		//	processBuilder.command("cmd.exe", "/c", potentialArduinoCLIPathCommand + commandSequence);
		//}
		//else{
			processBuilder.command("bash", "-c", potentialArduinoCLIPathCommand + commandSequence);
		//}
		Process proc = processBuilder.start();
		
		// https://stackoverflow.com/questions/5711084/java-runtime-getruntime-getting-output-from-executing-a-command-line-program
		BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
		BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
		int exitCode = proc.waitFor();
		
		// Read the output from the command
		String currentNormalFeedback = null;
		String normalFeedback = "";
		while ((currentNormalFeedback = stdInput.readLine()) != null) {
		    //System.out.println(currentNormalFeedback);
			normalFeedback += currentNormalFeedback + "\n";
		}
		// Read any errors from the attempted command
		String currentErrorFeedback = null;
		String errorFeedback = "";
		while ((currentErrorFeedback = stdError.readLine()) != null) {
		    //System.out.println(currentErrorFeedback);
			errorFeedback += currentErrorFeedback + "\n";
		}
		
		return new ResponseFeedback(exitCode, normalFeedback, errorFeedback);
	}
	
}
